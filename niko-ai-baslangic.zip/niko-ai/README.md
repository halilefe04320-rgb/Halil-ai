# NİKO AI — başlangıç projesi

Bu klasör, telefona ana ekrandan eklenebilen bir **PWA arayüz prototipidir**. Şu an gerçek yapay zekâ değildir; sohbet yanıtı üretmez, web'de arama yapmaz ve görsel oluşturmaz.

## Telefona kurup arayüzü deneme
1. Bu klasörü bir GitHub deposuna yükle.
2. Depoda **Settings → Pages** bölümünü aç.
3. **Deploy from a branch** seçeneğini kullan; `main` ve `/ (root)` seç.
4. GitHub Pages adresi açılınca Android Chrome'da ziyaret et.
5. Chrome menüsünden **Ana ekrana ekle** seç.

## Gerçek yapay zekâya bağlamak için
Güvenli bir sunucu gerekir. Tarayıcıdaki `app.js` içine gizli API anahtarı koyma. API anahtarları ziyaretçilere görünür. Sunucuda şu uç noktalar oluşturulabilir:

- `POST /api/chat` — metin sohbeti
- `POST /api/search` — web araması
- `POST /api/image` — görsel üretimi

Arayüzdeki `send()` fonksiyonu daha sonra `/api/chat` adresine `fetch()` isteği gönderecek şekilde güncellenmelidir. Sunucu tarafında anahtarlar ortam değişkenlerinde tutulmalıdır.

## Önemli
- GitHub Pages statik dosyaları yayınlar; kendi başına yapay zekâ modeli çalıştırmaz.
- Gerçek sohbet, arama ve görsel üretimi için ayrı servisler ve muhtemelen kullanım limitleri/ücretleri gerekir.
- Bu prototip APK değildir; Android ana ekranına eklenen web uygulamasıdır.
