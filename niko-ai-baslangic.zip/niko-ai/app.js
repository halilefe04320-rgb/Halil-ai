const chat=document.querySelector('#chat');
const form=document.querySelector('#composer');
const input=document.querySelector('#prompt');
function addMessage(text,who){const el=document.createElement('div');el.className='msg '+who;const b=document.createElement('b');b.textContent=who==='user'?'Sen':'Niko';const p=document.createElement('p');p.textContent=text;el.append(b,p);chat.append(el);el.scrollIntoView({behavior:'smooth',block:'end'});}
async function send(text){if(!text.trim())return;addMessage(text,'user');input.value='';addMessage('Bu prototip henüz bir yapay zekâ servisine bağlı değil. Gerçek yanıtlar için README dosyasındaki sunucu bağlantısı tamamlanmalı.','niko');}
form.addEventListener('submit',e=>{e.preventDefault();send(input.value);});
document.querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>{input.value=b.dataset.prompt;input.focus();}));
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}
